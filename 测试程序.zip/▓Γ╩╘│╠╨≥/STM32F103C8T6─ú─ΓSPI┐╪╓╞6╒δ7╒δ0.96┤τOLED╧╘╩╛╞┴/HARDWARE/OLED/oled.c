

#include "oled.h"
#include "oledfont.h"


//OLED�Դ��ܹ���Ϊ8ҳ
//ÿҳ8�У�һ��128�����ص�
//OLED���Դ�
//��Ÿ�ʽ����.
//[0]0 1 2 3 ... 127 (0~7)��
//[1]0 1 2 3 ... 127 (8~15)��
//[2]0 1 2 3 ... 127 (16~23)��
//[3]0 1 2 3 ... 127 (24~31)��
//[4]0 1 2 3 ... 127 (32~39)��
//[5]0 1 2 3 ... 127 (40~47)��
//[6]0 1 2 3 ... 127 (48~55)��
//[7]0 1 2 3 ... 127 (56~63)��


//����ÿ��bit�洢OLEDÿ�����ص����ɫֵ(1-��(��ɫ),0-��(��ɫ))
//ÿ������Ԫ�ر�ʾ1��8�����ص㣬һ��128��
static unsigned char OLED_buffer[1024] = 
{
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};


/*******************************************************************
 * @name       :void OLED_Write_Byte(unsigned dat,unsigned cmd)
 * @date       :2022-06-22
 * @function   :��һ���ֽڵ�����д��OLED��Ļ
 * @parameters :dat:Ҫ��д������
                cmd:0-д������
								    1-д������
 * @retvalue   :��
********************************************************************/
void OLED_Write_Byte(unsigned dat,unsigned cmd)
{
	if(cmd)
	{
		OLED_DC_PIN_Set();
	}
	else
	{
		OLED_DC_PIN_Clr();
	}
	OLED_CS_PIN_Clr();
	SPI_WriteByte(dat);
	OLED_CS_PIN_Set();
}


/*******************************************************************
 * @name       :void OLED_Display_On(void)
 * @date       :2022-06-22
 * @function   :��OLED��ʾ
 * @parameters :��
 * @retvalue   :��
********************************************************************/ 	  
void OLED_Display_On(void)
{
	OLED_Write_Byte(0X8D,OLED_CMD);		//SET DCDC����
	OLED_Write_Byte(0X14,OLED_CMD);		//DCDC ON
	OLED_Write_Byte(0XAF,OLED_CMD);		//DISPLAY ON
}


/*******************************************************************
 * @name       :void OLED_Display_Off(void)
 * @date       :2022-06-22
 * @function   :�ر�OLED��ʾ
 * @parameters :��
 * @retvalue   :��
********************************************************************/    
void OLED_Display_Off(void)
{
	OLED_Write_Byte(0X8D,OLED_CMD);		//SET DCDC����
	OLED_Write_Byte(0X10,OLED_CMD);		//DCDC OFF
	OLED_Write_Byte(0XAE,OLED_CMD);		//DISPLAY OFF
}


/*******************************************************************
 * @name       :void OLED_Set_Pos(unsigned char x, unsigned char y)
 * @date       :2022-06-22
 * @function   :��OLED��Ļ����������
 * @parameters :x:x����
                y:y����
 * @retvalue   :��
********************************************************************/
void OLED_Set_Pos(unsigned char x, unsigned char y)
{
 	OLED_Write_Byte(YLevel+y/PAGE_SIZE,OLED_CMD);
	OLED_Write_Byte((((x+2)&0xf0)>>4)|0x10,OLED_CMD);
	OLED_Write_Byte(((x+2)&0x0f),OLED_CMD);
}


/*******************************************************************
 * @name       :void OLED_Reset(void)
 * @date       :2022-06-22
 * @function   :����OLED��Ļ��ʾ
 * @parameters :dat:0-��ʾȫ��
                    1-��ʾȫ��
 * @retvalue   :��
********************************************************************/ 
void OLED_Reset(void)
{
	OLED_RST_PIN_Set();
	delay_ms(100);
	OLED_RST_PIN_Clr();
	delay_ms(100);
	OLED_RST_PIN_Set();
}


/*******************************************************************
 * @name       :void OLED_Set_Pixel(unsigned char x, unsigned char y,unsigned char color)
 * @date       :2022-06-22
 * @function   :������ֵ����ΪRAM
 * @parameters :x:���ص�x����
                y:���ص�y����
								color:���ص����ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
********************************************************************/ 
void OLED_Set_Pixel(unsigned char x, unsigned char y,unsigned char color)
{
	if(color)
	{
		OLED_buffer[(y/PAGE_SIZE)*WIDTH+x]|= (1<<(y%PAGE_SIZE))&0xff;
	}
	else
	{
		OLED_buffer[(y/PAGE_SIZE)*WIDTH+x]&= ~((1<<(y%PAGE_SIZE))&0xff);
	}
}


/*******************************************************************
 * @name       :void OLED_Display(void)
 * @date       :2022-06-22
 * @function   :��OLED��Ļ����ʾ
 * @parameters :��
 * @retvalue   :��
********************************************************************/  
void OLED_Display(void)
{
	u8 i,n;
	for(i=0;i<PAGE_SIZE;i++)  
	{  
		OLED_Write_Byte (YLevel+i,OLED_CMD);			//����ҳ��ַ��0~7��
		OLED_Write_Byte (XLevelL,OLED_CMD);				//������ʾλ�á��е͵�ַ
		OLED_Write_Byte (XLevelH,OLED_CMD);				//������ʾλ�á��иߵ�ַ
		for(n=0;n<WIDTH;n++)
		{
			OLED_Write_Byte(OLED_buffer[i*WIDTH+n],OLED_DATA);
		}
	}		//������ʾ
}


/*******************************************************************
 * @name       :void OLED_Clear(unsigned dat)
 * @date       :2022-06-22
 * @function   :���OLED��Ļ��ʾ
 * @parameters :dat:0-��ʾȫ��
                    1-��ʾȫ��
 * @retvalue   :��
********************************************************************/
void OLED_Clear(unsigned dat)
{
	if(dat)
	{
		memset(OLED_buffer,0xff,sizeof(OLED_buffer));
	}
	else
	{
		memset(OLED_buffer,0,sizeof(OLED_buffer));
	}
	OLED_Display();
}


/*******************************************************************
 * @name       :void OLED_Init_GPIO(void)
 * @date       :2022-06-22
 * @function   :OLED���ų�ʼ��
 * @parameters :��
 * @retvalue   :��
********************************************************************/ 
void OLED_Init_GPIO(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(OLED_DC_CLK,ENABLE);					//ʹ�ܶ˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = OLED_DC_PIN;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;		//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		//�ٶ�50MHz
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
 	GPIO_SetBits(OLED_DC_PORT,OLED_DC_PIN);
	
	RCC_APB2PeriphClockCmd(OLED_CS_CLK,ENABLE);					//ʹ�ܶ˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = OLED_CS_PIN;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;		//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		//�ٶ�50MHz
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
 	GPIO_SetBits(OLED_CS_PORT,OLED_CS_PIN);
	
	RCC_APB2PeriphClockCmd(OLED_RST_CLK,ENABLE);				//ʹ�ܶ˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = OLED_RST_PIN;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;		//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		//�ٶ�50MHz
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
 	GPIO_SetBits(OLED_RST_PORT,OLED_RST_PIN);
	
	RCC_APB2PeriphClockCmd(SPI2_SCK_CLK,ENABLE);					//ʹ�ܶ˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = SPI2_SCK_PIN;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;		//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		//�ٶ�50MHz
 	GPIO_Init(SPI2_SCK_PORT, &GPIO_InitStructure);
 	GPIO_SetBits(SPI2_SCK_PORT,SPI2_SCK_PIN);
	
	RCC_APB2PeriphClockCmd(SPI2_MOSI_CLK,ENABLE);					//ʹ�ܶ˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = SPI2_MOSI_PIN;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;		//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		//�ٶ�50MHz
 	GPIO_Init(SPI2_MOSI_PORT, &GPIO_InitStructure);
 	GPIO_SetBits(SPI2_MOSI_PORT,SPI2_MOSI_PIN);
}


/*******************************************************************
 * @name       :void OLED_Init(void)
 * @date       :2022-06-22
 * @function   :��ʼ��OLED SSD1306����IC
 * @parameters :��
 * @retvalue   :��
********************************************************************/ 				    
void OLED_Init(void)
{
 	OLED_Init_GPIO();		//��ʼ��GPIO
	
 	delay_ms(200);
	OLED_Reset();				//��λOLED
	
	/**************��ʼ��SSD1306*****************/
	OLED_Write_Byte(0xAE,OLED_CMD);	/*display off*/
	OLED_Write_Byte(0x00,OLED_CMD);	/*set lower column address*/
	OLED_Write_Byte(0x10,OLED_CMD);	/*set higher column address*/
	OLED_Write_Byte(0x40,OLED_CMD);	/*set display start line*/
	OLED_Write_Byte(0xB0,OLED_CMD);	/*set page address*/
	OLED_Write_Byte(0x81,OLED_CMD);	/*contract control*/
	OLED_Write_Byte(0xFF,OLED_CMD);	/*128*/
	OLED_Write_Byte(0xA1,OLED_CMD);	/*set segment remap*/
	OLED_Write_Byte(0xA6,OLED_CMD);	/*normal / reverse*/
	OLED_Write_Byte(0xA8,OLED_CMD);	/*multiplex ratio*/
	OLED_Write_Byte(0x3F,OLED_CMD);	/*duty = 1/64*/
	OLED_Write_Byte(0xC8,OLED_CMD);	/*Com scan direction*/
	OLED_Write_Byte(0xD3,OLED_CMD);	/*set display offset*/
	OLED_Write_Byte(0x00,OLED_CMD);
	OLED_Write_Byte(0xD5,OLED_CMD);	/*set osc division*/
	OLED_Write_Byte(0x80,OLED_CMD);
	OLED_Write_Byte(0xD9,OLED_CMD);	/*set pre-charge period*/
	OLED_Write_Byte(0XF1,OLED_CMD);
	OLED_Write_Byte(0xDA,OLED_CMD);	/*set COM pins*/
	OLED_Write_Byte(0x12,OLED_CMD);
	OLED_Write_Byte(0xDB,OLED_CMD);	/*set vcomh*/
	OLED_Write_Byte(0x30,OLED_CMD);
	OLED_Write_Byte(0x8D,OLED_CMD);	/*set charge pump disable*/
	OLED_Write_Byte(0x14,OLED_CMD);
	OLED_Write_Byte(0xAF,OLED_CMD);	/*display ON*/
}


/*****************************************************************************
 * @name       :void SPI_WriteByte(u8 Data)
 * @date       :2022-06-22
 * @function   :ʹ��STM32������SPIд��һ���ֽڵ�����
 * @parameters :Byte:Ҫд�������
 * @retvalue   :
******************************************************************************/
void SPI_WriteByte(u8 Data)
{
	unsigned char i=0;
	for(i=8;i>0;i--)
	{
	  if(Data&0x80)	
		{
			SPI2_MOSI_PIN_SET(); //д����1
    }
		else
		{
			SPI2_MOSI_PIN_CLR(); //д����0
	  }
    SPI2_SCK_PIN_CLR();    //��ʱ����������     
    SPI2_SCK_PIN_SET();    //����1bit����
    Data<<=1; 
	}
}


/*******************************************************************
 * @name       :void OLED_DrawPoint(u8 x,u8 y,u8 color)
 * @date       :2022-06-22
 * @function   :��OLED��Ļ�л��Ƶ�
 * @parameters :x:���x����
                y:���y����
								color:�����ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
********************************************************************/
void OLED_DrawPoint(u8 x,u8 y,u8 color)
{
	OLED_Set_Pixel(x,y,color);
	OLED_Display();
}


/*******************************************************************
 * @name       :void OLED_Fill(u8 sx,u8 sy,u8 ex,u8 ey,u8 color)
 * @date       :2022-06-22
 * @function   :���ָ������
 * @parameters :sx:ָ������������ʼx����
                sy:ָ������������ʼy����
								ex:ָ���������Ľ���x����
								ey:ָ���������Ľ���y����
								color:ָ���������ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
********************************************************************/
void OLED_Fill(u8 sx,u8 sy,u8 ex,u8 ey,u8 color)
{
	u8 i,j;
	u8 width=ex-sx+1;			//�õ����Ŀ���
	u8 height=ey-sy+1;		//�߶�
	for(i=0;i<height;i++)
	{
		for(j=0;j<width;j++)
		{
				OLED_Set_Pixel(sx+j, sy+i,color);
		}
	}
	OLED_Display();
}


/*******************************************************************
 * @name       :void OLED_DrawLine(u8 x1, u8 y1, u8 x2, u8 y2,u8 color)
 * @date       :2022-06-22
 * @function   :������֮�仭һ����
 * @parameters :x1:�ߵ���ʼx������
                y1:�ߵ���ʼy������
								x2:�ߵĽ���x������
								y2:�ߵĽ���y������
								color:��������ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
********************************************************************/
void OLED_DrawLine(u8 x1, u8 y1, u8 x2, u8 y2,u8 color)
{
	u16 t;
	int xerr=0,yerr=0,delta_x,delta_y,distance;
	int incx,incy,uRow,uCol;
	
	delta_x=x2-x1; //������������
	delta_y=y2-y1;
	uRow=x1;
	uCol=y1;
	if(delta_x>0)incx=1; //���õ�������
	else if(delta_x==0)incx=0;//��ֱ��
	else {incx=-1;delta_x=-delta_x;}
	if(delta_y>0)incy=1;
	else if(delta_y==0)incy=0;//ˮƽ��
	else{incy=-1;delta_y=-delta_y;}
	if( delta_x>delta_y)distance=delta_x; //ѡȡ��������������
	else distance=delta_y;
	for(t=0;t<=distance+1;t++ )//�������
	{
		OLED_Set_Pixel(uRow,uCol,color);
		xerr+=delta_x ;
		yerr+=delta_y ;
		if(xerr>distance)
		{
			xerr-=distance;
			uRow+=incx;
		}
		if(yerr>distance)
		{
			yerr-=distance;
			uCol+=incy;
		}
	}
	OLED_Display();
}


/*****************************************************************************
 * @name       :void OLED_DrawRectangle(u8 x1, u8 y1, u8 x2, u8 y2,u8 color)
 * @date       :2022-06-22
 * @function   :���ƾ���
 * @parameters :x1:���ε���ʼx����
                y1:���ε���ʼy����
								x2:���εĽ���x����
								y2:���εĽ���y����
								color:��������ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
******************************************************************************/
void OLED_DrawRectangle(u8 x1, u8 y1, u8 x2, u8 y2,u8 color)
{
	OLED_DrawLine(x1,y1,x2,y1,color);
	OLED_DrawLine(x1,y1,x1,y2,color);
	OLED_DrawLine(x1,y2,x2,y2,color);
	OLED_DrawLine(x2,y1,x2,y2,color);
}


/*****************************************************************************
 * @name       :void OLED_FillRectangle(u8 x1, u8 y1, u8 x2, u8 y2,u8 color)
 * @date       :2022-06-22
 * @function   :������
 * @parameters :x1:�����ε���ʼx����
                y1:�����ε���ʼy����
								x2:�����εĽ���x����
								y2:�����εĽ���y����
								color:���ε���ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
******************************************************************************/  
void OLED_FillRectangle(u8 x1, u8 y1, u8 x2, u8 y2,u8 color)
{
	OLED_Fill(x1,y1,x2,y2,color);
}

 
/*****************************************************************************
 * @name       :static void _draw_circle_8(u8 xc, u8 yc, u8 x, u8 y, u8 color)
 * @date       :2022-06-22
 * @function   :�Գ�Բ�����㷨���ڲ����ã�
 * @parameters :xc:Բ�ĵ�x����
                yc:Բ�ĵ�y����
								x:�����Բ�ĵ�x����
								y:�����Բ�ĵ�y����
								color:Բ����ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
******************************************************************************/
static void _draw_circle_8(u8 xc, u8 yc, u8 x, u8 y, u8 color)
{
	OLED_Set_Pixel(xc + x, yc + y, color);
	OLED_Set_Pixel(xc - x, yc + y, color);
	OLED_Set_Pixel(xc + x, yc - y, color);
	OLED_Set_Pixel(xc - x, yc - y, color);
	OLED_Set_Pixel(xc + y, yc + x, color);
	OLED_Set_Pixel(xc - y, yc + x, color);
	OLED_Set_Pixel(xc + y, yc - x, color);
	OLED_Set_Pixel(xc - y, yc - x, color);
}


/*****************************************************************************
 * @name       :void OLED_DrawCircle(u8 xc, u8 yc, u8 color, u8 r)
 * @date       :2022-06-22
 * @function   :��ָ��λ�û���ָ����С��Բ
 * @parameters :xc:Բ�ĵ�x����
                yc:Բ�ĵ�y����
								r:Բ�ΰ뾶
								color:Բ����ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
******************************************************************************/
void OLED_DrawCircle(u8 xc, u8 yc, u8 color, u8 r)
{
	int x = 0, y = r,d;
	d = 3 - 2 * r;
	while (x <= y)
	{
		_draw_circle_8(xc, yc, x, y, color);
		if (d < 0)
		{
				d = d + 4 * x + 6;
		}
		else
		{
				d = d + 4 * (x - y) + 10;
				y--;
		}
		x++;
	}
	OLED_Display();
}


/*****************************************************************************
 * @name       :void OLED_FillCircle(u8 xc, u8 yc, u8 color, u8 r)
 * @date       :2022-06-22
 * @function   :��ָ��λ�����ָ����С��Բ
 * @parameters :xc:Բ�ĵ�x����
                yc:Բ�ĵ�y����
								r:Բ�ΰ뾶
								color:Բ����ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
******************************************************************************/
void OLED_FillCircle(u8 xc, u8 yc, u8 color, u8 r)
{
	int x = 0, y = r, yi, d;
	d = 3 - 2 * r;
	while (x <= y)
	{
			for (yi = x; yi <= y; yi++)
			{
				_draw_circle_8(xc, yc, x, yi, color);
			}
			if (d < 0)
			{
				d = d + 4 * x + 6;
			}
			else
			{
				d = d + 4 * (x - y) + 10;
				y--;
			}
			x++;
	}
	OLED_Display();
}


/**********************************************************************************
 * @name       :void OLED_DrawTriangel(u8 x0,u8 y0,u8 x1,u8 y1,u8 x2,u8 y2,u8 color)
 * @date       :2022-06-22 
 * @function   :��ָ��λ�û���������
 * @parameters :x0:�����εĵ�һ��x����
                y0:�����εĵ�һ��y����
								x1:�����εĵڶ���x����
								y1:�����εĵڶ���y����
								x2:�����εĵ�����x����
								y2:�����εĵ�����y����
								color:�����ε���ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
***********************************************************************************/
void OLED_DrawTriangel(u8 x0,u8 y0,u8 x1,u8 y1,u8 x2,u8 y2,u8 color)
{
	OLED_DrawLine(x0,y0,x1,y1,color);
	OLED_DrawLine(x1,y1,x2,y2,color);
	OLED_DrawLine(x2,y2,x0,y0,color);
}



/*****************************************************************************
 * @name       :static void _swap(u8 *a, u8 *b)
 * @date       :2022-06-22
 * @function   :�����������루�ڲ�ͨ����
 * @parameters :a:��һ������ĵ�ַ
								b:�ڶ�������ĵ�ַ
 * @retvalue   :��
******************************************************************************/
static void _swap(u8 *a, u8 *b)
{
	u16 tmp;
  tmp = *a;
	*a = *b;
	*b = tmp;
}


/*****************************************************************************
 * @name       :static void _draw_h_line(u8 x0,u8 x1,u8 y,u8 color)
 * @date       :2022-06-22
 * @function   :����ʾ���л�һ��ˮƽ�ߣ��ڲ����ã�
 * @parameters :x0:ˮƽ�ߵ���ʼx����
                x1:ˮƽ�ߵĽ���x����
								y:ˮƽ�ߵ�y����
								color:�ߵ���ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
******************************************************************************/
static void _draw_h_line(u8 x0,u8 x1,u8 y,u8 color)
{
	u8 i=0;
	for(i=x0;i<=x1;i++)
	{
		OLED_Set_Pixel(i, y, color);
	}
}


/*****************************************************************************
 * @name       :void OLED_FillTriangel(u8 x0,u8 y0,u8 x1,u8 y1,u8 x2,u8 y2,u8 color)
 * @date       :2022-06-22
 * @function   :��ָ��λ�����������
 * @parameters :x0:�����εĵ�һ��x����
                y0:�����εĵ�һ��y����
								x1:�����εĵڶ���x����
								y1:�����εĵڶ���y����
								x2:�����εĵ�����x����
								y2:�����εĵ�����y����
								color:�����ε���ɫֵ
								      1-��ɫ
											0-��ɫ
 * @retvalue   :��
******************************************************************************/
void OLED_FillTriangel(u8 x0,u8 y0,u8 x1,u8 y1,u8 x2,u8 y2,u8 color)
{
	u8 a, b, y, last;
	int dx01, dy01, dx02, dy02, dx12, dy12;
	long sa = 0;
	long sb = 0;
 	if (y0 > y1)
	{
    _swap(&y0,&y1);
		_swap(&x0,&x1);
 	}
 	if (y1 > y2)
	{
    _swap(&y2,&y1);
		_swap(&x2,&x1);
 	}
  if (y0 > y1)
	{
    _swap(&y0,&y1);
		_swap(&x0,&x1);
  }
	if(y0 == y2)
	{
		a = b = x0;
		if(x1 < a)
    {
			a = x1;
    }
    else if(x1 > b)
    {
			b = x1;
    }
    if(x2 < a)
    {
			a = x2;
    }
		else if(x2 > b)
    {
			b = x2;
    }
		_draw_h_line(a,b,y0,color);
    return;
	}
	dx01 = x1 - x0;
	dy01 = y1 - y0;
	dx02 = x2 - x0;
	dy02 = y2 - y0;
	dx12 = x2 - x1;
	dy12 = y2 - y1;
	
	if(y1 == y2)
	{
		last = y1;
	}
  else
	{
		last = y1-1;
	}
	for(y=y0; y<=last; y++)
	{
		a = x0 + sa / dy01;
		b = x0 + sb / dy02;
		sa += dx01;
    sb += dx02;
    if(a > b)
    {
			_swap(&a,&b);
		}
		_draw_h_line(a,b,y,color);
	}
	sa = dx12 * (y - y1);
	sb = dx02 * (y - y0);
	for(; y<=y2; y++)
	{
		a = x1 + sa / dy12;
		b = x0 + sb / dy02;
		sa += dx12;
		sb += dx02;
		if(a > b)
		{
			_swap(&a,&b);
		}
		_draw_h_line(a,b,y,color);
	}
	OLED_Display();
}


/*****************************************************************************
 * @name       :void OLED_ShowChar(u8 x,u8 y,u8 chr,u8 Char_Size,u8 mode)
 * @date       :2022-06-22
 * @function   :��ʾ����Ӣ���ַ�
 * @parameters :x:�ַ���ʾλ�õ���ʼx����
                y:�ַ���ʾλ�õ���ʼy����
								chr:��ʾ�ַ���ascii�루0��94��
								Char_Size:��ʾ�ַ��Ĵ�С��8,16��
								mode:0-�׵׺���
								     1-�ڵװ���
 * @retvalue   :��
******************************************************************************/
void OLED_ShowChar(u8 x,u8 y,u8 chr,u8 Char_Size,u8 mode)
{
	unsigned char c=0,i=0,tmp,j=0;
	c=chr-' ';											//�õ�ƫ�ƺ��ֵ
	if(x>WIDTH-1){x=0;y=y+2;}
	if(Char_Size ==16)
	{
		for(i=0;i<16;i++)
		{
			if(mode)
			{
				tmp = F8X16[c*16+i];
			}
			else
			{
				tmp = ~(F8X16[c*16+i]);
			}
			for(j=0;j<8;j++)
			{
				if(tmp&(0x80>>j))
				{
					OLED_Set_Pixel(x+j, y+i,1);
				}
				else
				{
					OLED_Set_Pixel(x+j, y+i,0);
				}
			}
		}
	}
	else if(Char_Size==8)
	{
		for(i=0;i<8;i++)
		{
			if(mode)
			{
				tmp = F6x8[c][i];
			}
			else
			{
				tmp = ~(F6x8[c][i]);
			}
			for(j=0;j<8;j++)
			{
				if(tmp&(0x80>>j))
				{
					OLED_Set_Pixel(x+j, y+i,1);
				}
				else
				{
					OLED_Set_Pixel(x+j, y+i,0);
				}
			}
		}
	}
	else
	{
		return;
	}
	OLED_Display();
}


/*****************************************************************************
 * @name       :void OLED_ShowString(u8 x,u8 y,u8 *chr,u8 Char_Size,u8 mode)
 * @date       :2022-06-22 
 * @function   :��ʾӢ���ַ���
 * @parameters :x:Ӣ���ַ�������ʼx����
                y:Ӣ���ַ�������ʼy����
								chr:Ӣ���ַ�������ʼ��ַ
								Char_Size:��ʾ�ַ��Ĵ�С
								mode:0-�׵׺���
								     1-�ڵװ���
 * @retvalue   :��
******************************************************************************/
void OLED_ShowString(u8 x,u8 y,u8 *chr,u8 Char_Size,u8 mode)
{
	unsigned char j=0,csize;
	if(Char_Size == 16)
  {
	  csize = Char_Size/2;
	}
  else if(Char_Size == 8)
  {
	  csize = Char_Size/2+2;
	}
	else
	{
		return;
	}
	while (chr[j]!='\0')
	{
		OLED_ShowChar(x,y,chr[j],Char_Size,mode);
		x+=csize;
		if(x>120)
		{
			x=0;
			y+=Char_Size;
		}
		j++;
	}
}


/*****************************************************************************
 * @name       :u32 mypow(u8 m,u8 n)
 * @date       :2022-06-22 
 * @function   :��ȡm��n�η����ڲ����ã�
 * @parameters :m:the multiplier
                n:the power
 * @retvalue   :m��n�η�
******************************************************************************/
static u32 mypow(u8 m,u8 n)
{
	u32 result=1;
	while(n--)result*=m;
	return result;
}


/*****************************************************************************
 * @name       :void OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 Size,u8 mode)
 * @date       :2022-06-22 
 * @function   :��ʾ����
 * @parameters :x:���ֵ���ʼx����
                y:���ֵ���ʼy����
								num:���֣�0��4294967295��
								len:��ʾ���ֵĳ���
								Size:��ʾ���ֵĴ�С
								mode:0-�׵׺���
								     1-�ڵװ���
 * @retvalue   :��
******************************************************************************/
void OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 Size,u8 mode)
{
	u8 t,temp;
	u8 enshow=0,csize;
  if(Size == 16)
  {
	  csize = Size/2;
	}
  else if(Size == 8)
  {
	  csize = Size/2+2;
	}
	else
	{
		return;
	}
	for(t=0;t<len;t++)
	{
		temp=(num/mypow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				OLED_ShowChar(x+csize*t,y,' ',Size,mode);
				continue;
			}else enshow=1;
			
		}
	 	OLED_ShowChar(x+csize*t,y,temp+'0',Size,mode);
	}
}


/*****************************************************************************
 * @name       :void OLED_ShowFont16(u8 x,u8 y,u8 *s,u8 mode)
 * @date       :2022-06-22
 * @function   :��ʾ����16x16����
 * @parameters :x:���ֵ���ʼx����
                y:���ֵ���ʼy����
								s:���ֵ���ʼ��ַ
								mode:0-�׵׺���
								     1-�ڵװ���
 * @retvalue   :��
******************************************************************************/ 
void OLED_ShowFont16(u8 x,u8 y,u8 *s,u8 mode)
{
	u8 i,j,k,tmp;
	u16 num;
	num = sizeof(cfont16)/sizeof(typFNT_GB16);
  for(i=0;i<num;i++)
	{
		if((cfont16[i].Index[0]==*s)&&(cfont16[i].Index[1]==*(s+1)))
		{
			for(j=0;j<32;j++)
			{
				if(mode)
				{
					tmp = cfont16[i].Msk[j];
				}
				else
				{
					tmp = ~(cfont16[i].Msk[j]);
				}
				for(k=0;k<8;k++)
				{
					if(tmp&(0x80>>k))
					{
						OLED_Set_Pixel(x+(j%2)*8+k, y+j/2,1);
					}
					else
					{
						OLED_Set_Pixel(x+(j%2)*8+k, y+j/2,0);
					}
				}
			}	
			break;
		}	
	}
	OLED_Display();
}

/*****************************************************************************
 * @name       :void OLED_ShowFont24(u8 x,u8 y,u8 *s,u8 mode)
 * @date       :2022-06-22
 * @function   :��ʾ����24x24����
 * @parameters :x:���ֵ���ʼx����
                y:���ֵ���ʼy����
								s:���ֵ���ʼ��ַ
								mode:0-�׵׺���
								     1-�ڵװ���
 * @retvalue   :��
******************************************************************************/ 
void OLED_ShowFont24(u8 x,u8 y,u8 *s,u8 mode)
{
	u8 i,j,k,tmp;
	u16 num;
	num = sizeof(cfont24)/sizeof(typFNT_GB24);
  for(i=0;i<num;i++)
	{
		if((cfont24[i].Index[0]==*s)&&(cfont24[i].Index[1]==*(s+1)))
		{
			for(j=0;j<72;j++)
			{
				if(mode)
				{
					tmp = cfont24[i].Msk[j];
				}
				else
				{
					tmp = ~(cfont24[i].Msk[j]);
				}
				for(k=0;k<8;k++)
				{
					if(tmp&(0x80>>k))
					{
						OLED_Set_Pixel(x+(j%3)*8+k, y+j/3,1);
					}
					else
					{
						OLED_Set_Pixel(x+(j%3)*8+k, y+j/3,0);
					}
				}
			}	
			break;
		}	
	}
	OLED_Display();
}

/*****************************************************************************
 * @name       :void OLED_ShowFont32(u8 x,u8 y,u8 *s,u8 mode)
 * @date       :2022-06-22
 * @function   :��ʾ����32x32����
 * @parameters :x:���ֵ���ʼx����
                y:���ֵ���ʼy����
								s:���ֵ���ʼ��ַ
								mode:0-�׵׺���
								     1-�ڵװ���
 * @retvalue   :��
******************************************************************************/
void OLED_ShowFont32(u8 x,u8 y,u8 *s,u8 mode)
{
	u8 i,j,k,tmp;
	u16 num;
	num = sizeof(cfont32)/sizeof(typFNT_GB32);
  for(i=0;i<num;i++)
	{
		if((cfont32[i].Index[0]==*s)&&(cfont32[i].Index[1]==*(s+1)))
		{
			for(j=0;j<128;j++)
			{
				if(mode)
				{
					tmp = cfont32[i].Msk[j];
				}
				else
				{
					tmp = ~(cfont32[i].Msk[j]);
				}
				for(k=0;k<8;k++)
				{
					if(tmp&(0x80>>k))
					{
						OLED_Set_Pixel(x+(j%4)*8+k, y+j/4,1);
					}
					else
					{
						OLED_Set_Pixel(x+(j%4)*8+k, y+j/4,0);
					}
				}
			}
			break;
		}
	}
	OLED_Display();
}


/*****************************************************************************
 * @name       :void OLED_ShowCHinese(u8 x,u8 y,u8 hsize,u8 *str,u8 mode)
 * @date       :2022-06-22 
 * @function   :��ʾ�����ַ���
 * @parameters :x:�����ַ�������ʼx����
                y:�����ַ�������ʼy����
								size:�����ַ����Ĵ�С
								str:�����ַ�������ʼ��ַ
								mode:0-�׵׺���
								     1-�ڵװ���
 * @retvalue   :��
******************************************************************************/
void OLED_ShowCHinese(u8 x,u8 y,u8 hsize,u8 *str,u8 mode)
{
	while(*str!='\0')
	{
		if(hsize == 16)
		{
			OLED_ShowFont16(x,y,str,mode);
		}
		else if(hsize == 24)
		{
			OLED_ShowFont24(x,y,str,mode);
		}
		else if(hsize == 32)
		{
			OLED_ShowFont32(x,y,str,mode);
		}
		else
		{
			return;
		}
		x+=hsize;
		if(x>WIDTH-hsize)
		{
			x=0;
			y+=hsize;
		}
		str+=2;
	}
}


/*****************************************************************************
 * @name       :void OLED_DrawBMP(u8 x,u8 y,u8 width, u8 height, u8 BMP[], u8 mode)
 * @date       :2022-06-22
 * @function   :��ʾBMP��ɫͼƬ
 * @parameters :x:BMP��ɫͼƬ����ʼx����
                y:BMP��ɫͼƬ����ʼy����
								width:BMP��ɫͼƬ�Ŀ���
								height:BMP��ɫͼƬ�ĸ߶�
								BMP:BMP��ɫͼ�����е���ʼ��ַ
								mode:0-�׵׺���
								     1-�ڵװ���
 * @retvalue   :��
******************************************************************************/
void OLED_DrawBMP(u8 x,u8 y,u8 width, u8 height, u8 BMP[], u8 mode)
{
 u8 i,j,k;
 u8 tmp;
 for(i=0;i<height;i++)
 {
		for(j=0;j<(width+7)/8;j++)
		{
			if(mode)
			{
				tmp = BMP[i*((width+7)/8)+j];
			}
			else
			{
				tmp = ~BMP[i*((width+7)/8)+j];
			}
			for(k=0;k<8;k++)
			{
				if(tmp&(0x80>>k))
				{
					OLED_Set_Pixel(x+j*8+k, y+i,1);
				}
				else
				{
					OLED_Set_Pixel(x+j*8+k, y+i,0);
				}
			}
		}
	}
	OLED_Display();
}


/*****************************************************************************
 * @name       :void OLED_Test_MainPage(void)
 * @date       :2022-06-22
 * @function   :�����ۺϲ��Գ���������
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_Test_MainPage(void)
{
	OLED_ShowString(28,0,"dck",16,1);					//��ʾӢ���ַ���
	OLED_ShowCHinese(28,20,16,"������",1);			//��ʾ���ĺ���
	//OLED_ShowString(40,32,"64X128",16,1);
	OLED_ShowString(4,48,"631907030123",16,1);	//��ʾ����
	//OLED_ShowString(4,48,"www.lcdwiki.com",16,1);
	delay_ms(1500);
	delay_ms(1500);
}


/*****************************************************************************
 * @name       :void OLED_Test_Color(void)
 * @date       :2022-06-22
 * @function   :��ɫ�����ԣ���ɫ����ɫ��
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_Test_Color(void)
{
	 OLED_Fill(0,0,WIDTH-1,HEIGHT-1,0);
	 OLED_ShowString(10,10,"BLACK",16,1);
	 delay_ms(1000);
	 OLED_Fill(0,0,WIDTH-1,HEIGHT-1,1);
	 delay_ms(1500);
}


/*****************************************************************************
 * @name       :void OLED_Test_Rectangular(void))
 * @date       :2022-06-22
 * @function   :������ʾ��������
								������ʾ�ڰ׾��ο�1000����������ú�ɫ�Ͱ�ɫ������
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_Test_Rectangular(void)
{
	OLED_Fill(0,0,WIDTH/2-1,HEIGHT-1,0);
	OLED_Fill(WIDTH/2,0,WIDTH-1,HEIGHT-1,1);
	OLED_DrawRectangle(5, 5, WIDTH/2-1-5, HEIGHT-1-5,1);
	OLED_DrawRectangle(WIDTH/2-1+5, 5, WIDTH-1-5, HEIGHT-1-5,0);
	delay_ms(1000);
	OLED_FillRectangle(5, 5, WIDTH/2-1-5, HEIGHT-1-5,1);
	OLED_FillRectangle(WIDTH/2-1+5, 5, WIDTH-1-5, HEIGHT-1-5,0);
	delay_ms(1500);
}


/*****************************************************************************
 * @name       :void OLED_Test_Circle(void)
 * @date       :2022-06-22
 * @function   :ѭ����ʾ��������������ʾ�ڰ�Բ�ο�1000����������ú�ɫ����ɫ���Բ��
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_Test_Circle(void)
{
	OLED_Fill(0,0,WIDTH/2-1,HEIGHT-1,0);
	OLED_Fill(WIDTH/2,0,WIDTH-1,HEIGHT-1,1);
	OLED_DrawCircle(WIDTH/2/2-1, HEIGHT/2-1, 1, 27);
	OLED_DrawCircle(WIDTH/2+WIDTH/2/2-1, HEIGHT/2-1, 0, 27);
	delay_ms(1000);
	OLED_FillCircle(WIDTH/2/2-1, HEIGHT/2-1, 1, 27);
	OLED_FillCircle(WIDTH/2+WIDTH/2/2-1, HEIGHT/2-1, 0, 27);
	delay_ms(1500);
}


/*****************************************************************************
 * @name       :void OLED_Test_Triangle(void)
 * @date       :2022-06-22
 * @function   :��������ʾ��������������ʾ�ڰ������ο�1000����������ú�ɫ�Ͱ�ɫ���������
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_Test_Triangle(void)
{
	OLED_Fill(0,0,WIDTH/2-1,HEIGHT-1,0);
	OLED_Fill(WIDTH/2,0,WIDTH-1,HEIGHT-1,1);
	OLED_DrawTriangel(5,HEIGHT-1-5,WIDTH/2/2-1,5,WIDTH/2-1-5,HEIGHT-1-5,1);
	OLED_DrawTriangel(WIDTH/2-1+5,HEIGHT-1-5,WIDTH/2+WIDTH/2/2-1,5,WIDTH-1-5,HEIGHT-1-5,0);
	delay_ms(1000);
	OLED_FillTriangel(5,HEIGHT-1-5,WIDTH/2/2-1,5,WIDTH/2-1-5,HEIGHT-1-5,1);
	OLED_FillTriangel(WIDTH/2-1+5,HEIGHT-1-5,WIDTH/2+WIDTH/2/2-1,5,WIDTH-1-5,HEIGHT-1-5,0);
	delay_ms(1500);
}


/*****************************************************************************
 * @name       :void OLED_TEST_English(void)
 * @date       :2022-06-22
 * @function   :Ӣ����ʾ����
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_TEST_English(void)
{
	OLED_ShowString(0,5,"6x8:abcdefghijklmnopqrstuvwxyz",8,1);
	OLED_ShowString(0,25,"8x16:abcdefghijklmnopqrstuvwxyz",16,1);
	delay_ms(1000);
	OLED_ShowString(0,5,"6x8:ABCDEFGHIJKLMNOPQRSTUVWXYZ",8,1);
	OLED_ShowString(0,25,"8x16:ABCDEFGHIJKLMNOPQRSTUVWXYZ",16,1);
	delay_ms(1500);
}


/*****************************************************************************
 * @name       :void OLED_TEST_Number_Character(void) 
 * @date       :2022-06-22
 * @function   :���ֺ��ַ���ʾ����
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_TEST_Number_Character(void)
{
	OLED_Fill(0,0,WIDTH-1,HEIGHT/2-1,0);
	OLED_ShowString(0,0,"6x8:!\"#$%&'()*+,-./:;<=>?@[]\\^_`~{}|",8,1);
	OLED_ShowNum(30,16,1234567890,10,8,1);
	delay_ms(1000);
	OLED_Clear(0);
  OLED_ShowString(0,0,"8x16:!\"#$%&'()*+,-./:;<=>?@[]\\^_`~{}|",16,1);
	OLED_ShowNum(40,32,1234567890,10,16,1);
	delay_ms(1500);
	OLED_Clear(0);
}


/*****************************************************************************
 * @name       :void OLED_Test_Chinese(void)
 * @date       :2022-06-22
 * @function   :������ʾ����
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_Test_Chinese(void)
{
	OLED_ShowString(45,0,"16x16",8,1);
	OLED_ShowCHinese(16,20,16,"������",1);
	delay_ms(1000);
	OLED_Clear(0);
	OLED_ShowString(45,0,"24x24",8,1);
	OLED_ShowCHinese(16,20,24,"������",1);
	delay_ms(1000);
	OLED_Clear(0);
	OLED_ShowString(45,0,"32x32",8,1);
	OLED_ShowCHinese(0,20,32,"������",1);
  delay_ms(1000);
	OLED_Clear(0);
}


/*****************************************************************************
 * @name       :void OLED_Test_BMP(void)
 * @date       :2022-06-22
 * @function   :BMP��ɫͼƬ��ʾ����
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_Test_BMP(void)
{
	OLED_DrawBMP(0,0,128,64, BMP2, 1);
	delay_ms(1000);
	OLED_DrawBMP(0,0,128,64, BMP3, 1);
	delay_ms(1000);
	OLED_DrawBMP(0,0,128,64, BMP4, 1);
	delay_ms(1000);
}


/*****************************************************************************
 * @name       :void OLED_Test_Menu1(void)
 * @date       :2022-06-22
 * @function   :����ѡ��˵���ʾ����
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_Test_Menu1(void)
{
	OLED_Fill(0,0,WIDTH-1,15,1);
	OLED_ShowCHinese(32,0,16,"ϵͳ����",0);
	OLED_DrawCircle(10, 24, 1,6);
	OLED_DrawCircle(10, 24, 1,3);
	OLED_DrawCircle(10, 40, 1,6);
	OLED_DrawCircle(10, 40, 1,3);
	OLED_DrawCircle(10, 56, 1,6);
	OLED_DrawCircle(10, 56, 1,3);
	OLED_ShowString(20,16,"A.",16,1);
	OLED_ShowCHinese(36,16,16,"��������",1);
	OLED_ShowString(20,32,"B.",16,1);
	OLED_ShowCHinese(36,32,16,"��ɫ����",1);
	OLED_ShowString(20,48,"C.",16,1);
	OLED_ShowCHinese(36,48,16,"��������",1);
	OLED_DrawRectangle(0, 0,WIDTH-1,HEIGHT-1,1);
	OLED_DrawLine(WIDTH-1-10, 15, WIDTH-1-10, HEIGHT-1,1);
	OLED_FillTriangel(WIDTH-1-9,20,WIDTH-1-5,16,WIDTH-1-1,20,1);
	OLED_FillTriangel(WIDTH-1-9,HEIGHT-1-5,WIDTH-1-5,HEIGHT-1-1,WIDTH-1-1,HEIGHT-1-5,1);
	OLED_FillCircle(10, 24, 1,3);
	OLED_Fill(20,16,99,31,1);
	OLED_ShowString(20,16,"A.",16,0);
	OLED_ShowCHinese(36,16,16,"��������",0);
	OLED_Fill(WIDTH-1-9,23,WIDTH-1-1,28,1);
	delay_ms(1500);
	OLED_FillCircle(10, 24, 0,3);
	OLED_DrawCircle(10, 24, 1,3);
	OLED_Fill(20,16,99,31,0);
	OLED_ShowString(20,16,"A.",16,1);
	OLED_ShowCHinese(36,16,16,"��������",1);
	OLED_Fill(WIDTH-1-9,23,WIDTH-1-1,28,0);
	OLED_FillCircle(10, 40, 1,3);
	OLED_Fill(20,32,99,47,1);
	OLED_ShowString(20,32,"B.",16,0);
	OLED_ShowCHinese(36,32,16,"��ɫ����",0);
	OLED_Fill(WIDTH-1-9,37,WIDTH-1-1,42,1);
	delay_ms(1500);
	OLED_FillCircle(10, 40, 0,3);
	OLED_DrawCircle(10, 40, 1,3);
	OLED_Fill(20,32,99,47,0);
	OLED_ShowString(20,32,"B.",16,1);
	OLED_ShowCHinese(36,32,16,"��ɫ����",1);
	OLED_Fill(WIDTH-1-9,37,WIDTH-1-1,42,0);
	OLED_FillCircle(10, 56, 1,3);
	OLED_Fill(20,48,99,63,1);
	OLED_ShowString(20,48,"C.",16,0);
	OLED_ShowCHinese(36,48,16,"��������",0);
	OLED_Fill(WIDTH-1-9,HEIGHT-1-13,WIDTH-1-1,HEIGHT-1-8,1);
	delay_ms(1500);
}


/*****************************************************************************
 * @name       :void OLED_Test_Menu2(void)
 * @date       :2022-06-22
 * @function   :Ӣ������������ʾ����
 * @parameters :��
 * @retvalue   :��
******************************************************************************/
void OLED_Test_Menu2(void)
{
	u8 i;
	srand(123456);
	OLED_DrawLine(0, 10, WIDTH-1, 10,1);
	OLED_DrawLine(WIDTH/2-1,11,WIDTH/2-1,HEIGHT-1,1);
	OLED_DrawLine(WIDTH/2-1,10+(HEIGHT-10)/2-1,WIDTH-1,10+(HEIGHT-10)/2-1,1);
	OLED_ShowString(0,1,"2019-08-17",8,1);
	OLED_ShowString(78,1,"Saturday",8,1);
	OLED_ShowString(14,HEIGHT-1-10,"Cloudy",8,1);
	OLED_ShowString(WIDTH/2-1+2,13,"TEMP",8,1);
	OLED_DrawCircle(WIDTH-1-19, 25, 1,2);
	OLED_ShowString(WIDTH-1-14,20,"C",16,1);
	OLED_ShowString(WIDTH/2-1+9,20,"32.5",16,1);
	OLED_ShowString(WIDTH/2-1+2,39,"PM2.5",8,1);
	OLED_ShowString(WIDTH/2-1+5,46,"90ug/m3",16,1);
	OLED_DrawBMP(6,16,51,32, BMP5, 1);
	for(i=0;i<15;i++)
	{
		OLED_ShowNum(WIDTH/2-1+9,20,rand()%4,1,16,1);
		OLED_ShowNum(WIDTH/2-1+9+8,20,rand()%10,1,16,1);
		OLED_ShowNum(WIDTH/2-1+9+8+16,20,rand()%10,1,16,1);
		OLED_ShowNum(WIDTH/2-1+5,46,rand()%10,1,16,1);
		OLED_ShowNum(WIDTH/2-1+5+8,46,rand()%10,1,16,1);
    delay_ms(500);
	}
}


